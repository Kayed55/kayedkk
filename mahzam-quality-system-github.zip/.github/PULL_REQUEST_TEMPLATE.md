# Pull Request

## ما الذي يفعله هذا الـ PR؟ / What does this PR do?

<!-- وصف موجز للتغييرات -->

## نوع التغيير / Type of change

- [ ] 🐛 Bug fix
- [ ] ✨ New feature
- [ ] 🎨 UI/UX improvement
- [ ] 📝 Documentation update
- [ ] ♻️ Refactor (no behavior change)
- [ ] ⚡ Performance improvement
- [ ] 🔒 Security fix

## قائمة التحقق / Checklist

- [ ] الكود يتبع تنسيق المشروع (`npm run format`)
- [ ] لا توجد أخطاء في الـ JavaScript (`node --check`)
- [ ] تم تحديث `docs/CHANGELOG.md`
- [ ] تم اختبار التغييرات على المتصفح
- [ ] تم اختبار التصدير (PDF + Excel) إن وُجد تغيير ذو صلة
- [ ] الصور والشعار تظهر بشكل صحيح
- [ ] دعم RTL والعربية لم يتأثر

## لقطات شاشة / Screenshots

<!-- إن وُجدت -->

## أي ملاحظات إضافية؟ / Additional notes?
