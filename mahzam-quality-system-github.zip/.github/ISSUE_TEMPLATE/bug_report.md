---
name: 🐛 Bug Report
about: ابلاغ عن خطأ في النظام
title: '[BUG] '
labels: bug
assignees: ''
---

## وصف المشكلة / Bug description

<!-- وصف واضح ومختصر للخطأ -->

## خطوات إعادة الإنتاج / Steps to reproduce

1. اذهب إلى '...'
2. اضغط على '...'
3. شاهد الخطأ

## السلوك المتوقع / Expected behavior

<!-- ماذا كنت تتوقع أن يحدث؟ -->

## السلوك الفعلي / Actual behavior

<!-- ماذا حدث فعلاً؟ -->

## لقطات الشاشة / Screenshots

<!-- إن وُجدت، أرفق صوراً تشرح المشكلة -->

## البيئة / Environment

- **المتصفح**: (Chrome / Safari / Firefox / Edge)
- **الإصدار**: (مثال: 120.0)
- **نظام التشغيل**: (Windows / macOS / Linux / iOS / Android)
- **الدور**: (مدير / موظف جودة / مشرف / موظف)

## معلومات إضافية / Additional context

<!-- أي معلومات أخرى قد تساعد في حل المشكلة -->
