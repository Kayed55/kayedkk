---
name: ✨ Feature Request
about: اقتراح ميزة جديدة
title: '[FEATURE] '
labels: enhancement
assignees: ''
---

## الميزة المقترحة / Proposed feature

<!-- وصف واضح للميزة الجديدة -->

## المشكلة التي تحلها / Problem it solves

<!-- ما المشكلة التي ستحلها هذه الميزة؟ -->

## الحل المقترح / Proposed solution

<!-- كيف يمكن تنفيذ هذه الميزة؟ -->

## بدائل أخرى تم النظر فيها / Alternatives considered

<!-- هل هناك حلول أخرى ممكنة؟ -->

## معلومات إضافية / Additional context

<!-- لقطات شاشة، أمثلة من أنظمة مشابهة، إلخ -->
